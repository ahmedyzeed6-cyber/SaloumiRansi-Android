# مغامرات سلومي ورانسي — Android wrapper v28

هذا مشروع Android Studio لتغليف ملف اللعبة المعتمد v28 كما هو داخل WebView.

## البناء
1. افتح المجلد في Android Studio (يفضل إصدار يدعم Android Gradle Plugin 8.7.3).
2. اسمح بمزامنة Gradle وتنزيل Android SDK Platform 35 وAndroidX WebKit 1.12.1.
3. اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
4. ملف APK الناتج يظهر عادة في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات فنية
- اتجاه التطبيق أفقي Landscape.
- JavaScript وDOM Storage مفعّلان لحفظ التقدم محليًا.
- صفحة اللعبة محلية عبر WebViewAssetLoader على أصل HTTPS محلي.
- صلاحية الإنترنت موجودة لتحميل محرك Nabra TTS من jsDelivr كما في v28 الأصلية.
- لم يتم تعديل HTML أو مصدر الصوت أو بنك الأسئلة.

## حدود الاختبار في بيئة الإنشاء الحالية
تم تضمين HTML وفحص بنية المشروع ومصدر JavaScript. لا تتوفر Android SDK أو Gradle في بيئة الإنشاء الحالية، لذلك لم ينتج APK ولم يتم اختبار التثبيت على جهاز فعلي.
