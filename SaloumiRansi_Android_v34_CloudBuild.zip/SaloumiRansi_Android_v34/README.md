# مغامرات سلومي ورانسي — Android wrapper v34

هذا مشروع Android Studio لتغليف ملف اللعبة المعتمد v34 كما هو داخل WebView.

## البناء
1. افتح المجلد في Android Studio (يفضل إصدار يدعم Android Gradle Plugin 8.7.3).
2. اسمح بمزامنة Gradle وتنزيل Android SDK Platform 35 وAndroidX WebKit 1.12.1.
3. اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
4. ملف APK الناتج يظهر عادة في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات فنية
- اتجاه التطبيق أفقي Landscape.
- JavaScript وDOM Storage مفعّلان لحفظ التقدم محليًا.
- صفحة اللعبة محلية عبر WebViewAssetLoader على أصل HTTPS محلي.
- صلاحية الإنترنت موجودة لتحميل محرك Nabra TTS من jsDelivr كما في v34 الأصلية.
- لم يتم تعديل HTML أو مصدر الصوت أو بنك الأسئلة.

## حدود الاختبار في بيئة الإنشاء الحالية
تم تضمين HTML وفحص بنية المشروع ومصدر JavaScript. لا تتوفر Android SDK أو Gradle في بيئة الإنشاء الحالية، لذلك لم ينتج APK ولم يتم اختبار التثبيت على جهاز فعلي.

## البناء السحابي (بدون Android Studio على الهاتف)
المشروع يحتوي الآن على GitHub Actions workflow جاهز للبناء على خادم سحابي.

### خطوات استخراج APK
1. أنشئ مستودعًا جديدًا على GitHub باسم `SaloumiRansi-Android` واجعله **Private** إذا كنت تريد إبقاء ملفات اللعبة خاصة.
2. فك ضغط ملف المشروع على جهازك، ثم ارفع **محتويات مجلد** `SaloumiRansi_Android_v34` إلى جذر المستودع (يجب أن يظهر مجلد `.github/workflows` في الجذر بجانب `app` وملفات Gradle).
3. افتح تبويب **Actions** في المستودع. إذا طلب GitHub تفعيل Actions فوافق.
4. اختر **Build Saloumi Ransi APK** ثم **Run workflow**.
5. انتظر حتى تصبح نتيجة التشغيل خضراء. افتح التشغيل نفسه وانزل إلى **Artifacts**.
6. نزّل `Saloumi-Ransi-v34-debug-APK.zip` وفك ضغطه؛ ستجد بداخله `app-debug.apk`.
7. انقل APK إلى الهاتف وثبّته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

### ماذا يفعل البناء؟
- يستخدم JDK 17 وGradle 8.9 وAndroid SDK 35 على خادم GitHub.
- ينفذ `assembleDebug`، ويتحقق من وجود APK غير فارغ، ثم يرفعه كـ Artifact لمدة 30 يومًا.
- لا يعدّل ملف اللعبة `app/src/main/assets/index.html` ولا يغيّر مصدر الصوت.

**مهم:** لم يتم تنفيذ بناء سحابي بعد؛ يلزم رفع المشروع إلى مستودع GitHub وتشغيل الـ workflow من حسابك. نجاح إعداد هذا الملف لا يعني أن APK قد بُني بالفعل.
